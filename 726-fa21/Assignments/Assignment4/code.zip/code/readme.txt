All the code has been developed on the colab links are shared in the report as well as mentioned below. 

2.1) https://colab.research.google.com/drive/1GBjFh6IktdSv8AmBCREiWhdyhIASSdEw?usp=sharing
2.2) https://colab.research.google.com/drive/1h757_1bEupyJhrUicRKkMFgEFlS2T8hO?usp=sharing
2.3) https://colab.research.google.com/drive/1PcD2VKA6vSSlm56Wp4Tp9uULXHcNmUzW?usp=shar
ing
2.4) https://colab.research.google.com/drive/1vCpUqUjdA5xeTUcMGMoRZQ9AWAAEYW01?usp=sh
aring


For different cases mentioned in 2.3 and 2.4. Please do re-run after following the below mentioned instructions to verify the outputs

For question 2.3 readme is also present above forward function in Autoencoder class (autoencoder_sample_2_3.py file)

#Readme: 
      """ To run CASE 1: Without Dropout and Gaussian: Comment both add_noise lines in foward function
                 CASE 2: With Dropout : Comment add_noise with noise_type = Gaussian
                 CASE 3: With Gaussian : Comment add_noise with noise_type = Dropout
      """

For question 2.4 readme is also present near loss_function in VAE_starter.py file.
 # Readme 
    """
          CASE_1 Without KLD :  Comment line Loss = BCE + KLD
          CASE_2 With KLD : Comment line Loss = BCE
    """